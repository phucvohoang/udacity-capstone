
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'bushjdo',
  applicationName: 'serverless-udagram',
  appUid: 'ndWXxhhXvmW80ln0lH',
  orgUid: '41c29535-b67c-45ee-8184-5cbc7090c844',
  deploymentUid: '5790f232-d1ed-4be9-8764-151a72d0a956',
  serviceName: 'serverless-udagram',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-udagram-dev-CreatePost', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/createPost.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}