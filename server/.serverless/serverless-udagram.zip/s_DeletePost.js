
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'bushjdo',
  applicationName: 'serverless-udagram',
  appUid: 'ndWXxhhXvmW80ln0lH',
  orgUid: '41c29535-b67c-45ee-8184-5cbc7090c844',
  deploymentUid: 'b943eddd-e301-483e-a9aa-0a231d09cca3',
  serviceName: 'serverless-udagram',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-udagram-dev-DeletePost', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/deletePost.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}