
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'bushjdo',
  applicationName: 'serverless-udagram',
  appUid: 'ndWXxhhXvmW80ln0lH',
  orgUid: '41c29535-b67c-45ee-8184-5cbc7090c844',
  deploymentUid: 'ebe4e456-117c-4595-89ac-c9b8b925341e',
  serviceName: 'serverless-udagram',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-udagram-dev-GenerateUploadUrl', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/generateUploadUrl.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}